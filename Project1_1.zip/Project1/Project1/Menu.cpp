#include "Menu.h"
#include "SceneMgr.h"
#include "DxLib.h"

void Menu_Update() {
	if (CheckHitKey(KEY_INPUT_G) != 0) {
		SceneMgr_CharngeScene(eScene_Game);
	}
	if (CheckHitKey(KEY_INPUT_C) != 0) {
		SceneMgr_CharngeScene(eScene_Config);
	}

void
}