#pragma once
#ifndef __MENU_H__
#define __MENU_H__

void Menu_Update();

void Menu_Draw();

#endif __ MENU_H__