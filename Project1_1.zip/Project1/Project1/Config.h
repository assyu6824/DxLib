#pragma once
#ifndef __CONFIG_H__
#define __CONFIG_H__

void Config_Update();

void Config_Draw();

#endif __CONFIG_H__