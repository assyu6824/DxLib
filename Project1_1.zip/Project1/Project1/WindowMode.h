#pragma once
#ifndef __WINDOWMODE_H__
#define __WINDOWMODE_H__
#include "DxLib.h"


#endif //__WINDOWMODE_H__