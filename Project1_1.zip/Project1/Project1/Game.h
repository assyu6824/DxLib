#pragma once
#ifndef __GAME_H__
#define __GAME_H__

void Game_Update();

void Game_Draw();

#endif __GAME_H__