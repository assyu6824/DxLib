#pragma once
#ifndef __SCENEMGR_H__
#define __SCENEMGR_H__

typedef enum {
	eScene_Menu,
	eScene_Game,
	eScene_Config,
	eScene_None,
}eScene;

void SceneMgr_Initialize();
void SceneMgr_Finalize();
void SceneMgr_Update();
void SceneMgr_Draw();
void SceneMgr_ChangeScene(eScene nextScene);

#endif //__SCENEMGR_H__