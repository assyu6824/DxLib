#include "Game.h"
#include "DxLib.h"
#include "SceneMgr.h"

int Game_Col = GetColor(255, 0, 0);
static int mImageHandle;

void Game_Initialize(){
	mImageHandle = LoadGraph("�摜/images/Scene_Game.png");
}

void Game_Finalize() {
	DeleteGraph(mImageHandle);
}


void Game_Update() {
	if (CheckHitKey(KEY_INPUT_ESCAPE) != 0) {
		SceneMgr_ChangeScene(eScene_Menu);
	}
}

void Game_Draw() {
	DrawGraph(0, 0, mImageHandle,FALSE);
	DrawString(0, 0, "�Q�[����ʂł��B", Game_Col);
	DrawString(0, 20, "Esc�L�[�������ƃ��j���[��ʂɖ߂�܂��B", Game_Col);
}