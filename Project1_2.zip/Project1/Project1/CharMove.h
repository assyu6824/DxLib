#pragma once
#ifndef __CHARMOVE_H__
#define __CHARMOVE_H__
#include "DxLib.h"
int Key[256];

int gpUpdateKey() {//�L�[�{�[�h�̓��͂𔻒肷��
	char key[256];
	GetHitKeyStateAll(key);
	for (int i = 0; i < 256; i++) {
		if (key[i] != 0) {
			Key[i]++;
		}
		else {
			Key[i] = 0;
		}
	}
	return 0;
}


#endif __CHARMOVE_H__