#include "CharMove.h"
#include "SceneMgr.h"
#include "DxLib.h"

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
	ChangeWindowMode(TRUE), DxLib_Init(), SetDrawScreen(DX_SCREEN_BACK); //�E�B���h�E���[�h�ύX�Ə������Ɨ���ʐݒ�

	int Charactor[120];
	int x = 0,y=0;
	int FontCol = GetColor(125,255,0);
	//Charactor = LoadGraph("�摜/fantasy/���s�h�b�g�L����.bmp");
	//�����̕\��
	/*while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0) {
		DrawFormatString(x,y,FontCol,"�\���ŗ�����",x,y);
		x = x + 2; 
		y = y + 1;
	}*/
	//
	//DrawGraph(0, 0, Charactor, TRUE);
	//LoadGraphScreen(0, 0, "�摜/Live.jpg",TRUE);//�摜��\���ł��邪�����܂Ńe�X�g������!!

	/*while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0) {
		ProcessMessage();//���[�v����ꍇ�͕K�v
		if (ProcessMessage() != 0) {//Windows�́~�{�^���������ꂽ��
			break;//�\���I��
		}
		ClearDrawScreen();
		DrawGraph(x, 100, stage, TRUE);
		x = x + 10;
		ScreenFlip();
	}*/
	LoadDivGraph("�摜/fantasy/���s�h�b�g�L����.bmp", 120, 15, 8,32,32,Charactor);
	/*
	while ( ScreenFlip()== 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0) {
		DrawGraph(0, 0, Charactor[32],TRUE);
	}
	*/
	/*
	while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0) {
		DrawFormatString(x, 0, FontCol, "?!");
		if (CheckHitKey(KEY_INPUT_RIGHT) != 0) {
			x = x + 2;
		}
	}
	*/

	SceneMgr_Initialize();

	//�����̐���
	static int style = 30;
	static int Movestate = 0;
	while (ScreenFlip() == 0 && ProcessMessage() == 0 && ClearDrawScreen() == 0 && gpUpdateKey() == 0) {
		DrawGraph(x, y, Charactor[style], TRUE);//�L�����N�^�[��\��������
		if (Key[KEY_INPUT_RIGHT] == 1) {
			switch (Movestate) {
			case 0:
				style = 17;
				Movestate = 1;
				break;
			case 1:
				style = 16;
				Movestate = 2;
				break;
			case 2:
				style = 15;
				Movestate = 3;
				break;
			case 3:
				style = 16;
				Movestate = 0;
				break;
			}
			x = x + 50;
		}
		if (Key[KEY_INPUT_LEFT] == 1) {
			switch (Movestate) {
			case 0:
				style = 45;
				Movestate = 1;
				break;
			case 1:
				style = 46;
				Movestate = 2;
				break;
			case 2:
				style = 47;
				Movestate = 3;
				break;
			case 3:
				style = 46;
				Movestate = 0;
				break;
			}
			x = x - 50;
		}
		if (Key[KEY_INPUT_UP] == 1) {
			switch (Movestate) {
			case 0:
				style = 1;
				Movestate=1;
				break;
			case 1:
				style = 0;
				Movestate = 2;
				break;
			case 2:
				style = 2;
				Movestate = 3;
				break;
			case 3:
				style = 1;
				Movestate = 2;
				break;
			}
			y = y - 50;
		}
		if (Key[KEY_INPUT_DOWN] == 1) {
			switch (Movestate) {
			case 0:
				style = 30;
				Movestate++;
				break;
			case 1:
				style = 31;
				Movestate++;
				break;
			case 2:
				style = 32;
				Movestate = 3;
				break;
			case 3:
				style = 31;
				Movestate = 0;
				break;
			}
			y = y + 50;
		}
		
		SceneMgr_Update();
		SceneMgr_Draw();
	}
	SceneMgr_Finalize();

	WaitKey();
	DxLib_End();
	return 0;
}